# 🐊 Lacoste Cypress Automation

## Installation
```bash
git clone https://github.com/<username>/lacoste-tests.git
cd lacoste-tests
npm install
```

## Run tests locally
```bash
npx cypress open   # interactive mode
npx cypress run    # headless mode
```