const { defineConfig } = require("cypress");

module.exports = defineConfig({
  e2e: {
    baseUrl: "https://www.google.com",
    pageLoadTimeout: 120000, // attendre jusqu'à 2 minutes
    setupNodeEvents(on, config) {
      on('before:browser:launch', (browser = {}, launchOptions) => {
        if (browser.name === 'chrome' || 'edge') {
          launchOptions.args.push('--disable-site-isolation-trials');
          launchOptions.args.push('--disable-features=SameSiteByDefaultCookies,CookiesWithoutSameSiteMustBeSecure');
          launchOptions.args.push('--incognito');
        }
        return launchOptions;
        });
    },
  
  },
});