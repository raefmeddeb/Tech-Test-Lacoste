describe('Google search Lacoste US', () => {
  it('should open Lacoste US homepage correctly', () => {
    cy.visit('https://www.google.com');
    cy.get('button[id="L2AGLb"]').click()
    cy.get('textarea[name="q"]').type('Lacoste US{enter}');
    cy.wait(20000)  
    // je ne pouvais pas utilisé le href car il y a 2 elements existants.
    cy.get('h3')                                      // sélectionne tous les h3 sur la page
    .filter((index, h3) => h3.innerText.includes('Polos, chaussures et maroquinerie - Lacoste')) // filtre par texte
    .parents('a')                                   // remonte jusqu'au lien parent
    .first()                                        // prend le premier résultat
    .click({ timeout: 20000 }); 
    cy.wait(15000)
    // clicquer sur accepter tout les cookies
    cy.get('button[id="didomi-notice-agree-button"]').click({ timeout: 10000 });
    cy.url().should('include', 'lacoste.com/us');
    cy.title().should('include', 'Lacoste');
    cy.get('header img[alt="Lacoste"]').should('be.visible');
  });
});

