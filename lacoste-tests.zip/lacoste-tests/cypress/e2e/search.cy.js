describe('Lacoste FR site tests', () => {
  beforeEach(() => {
    cy.visit('https://www.lacoste.com/fr');
  });

  it('should search for polo and display results', () => {
    cy.get('input[type="search"]').type('polo{enter}');
    cy.get('.product-tile').should('exist');
  });
});